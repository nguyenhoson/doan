#tabu_search-vrpcd
A Tabu Search algorithm for solving Vehicle Routing Problem with Cross-Docking
